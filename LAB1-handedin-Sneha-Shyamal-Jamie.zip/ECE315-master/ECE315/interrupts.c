#include "interrupts.h"
extern volatile bool AlertSysTick; //50us
extern volatile bool Alert10ms; // 10ms
extern volatile bool Alert1s;   //  1s

extern volatile bool switchEdge;
extern volatile char leftBuf[4];

// systick handler which keeps track of the count
void SysTick_Handler(void){
	static uint32_t count1 = 0;
	static uint32_t count2 = 0;
	uint32_t val;
	AlertSysTick = true;
	
	count1++;
	count2++;
	
	// get the range and update count 
	if(count1>= 200){
		Alert10ms = true;
		count1 = 0;
	}
	
	if(count2 >= 20000){
		Alert1s = true;
		count2 = 0;
	}
	val = SysTick->VAL;
}

// Left sensor buffer 
// UART hanedler for UART7
void UART7_Handler(void){
	
	uint32_t i;
	// if the data is R then start collecting data
	if(UART7->DR == 'R'){
		for(i = 0; i < 3; i++){
			leftBuf[i] = UART7->DR;
		}
	}
	leftBuf[3] = NULL;
}

void GPIOE_Handler(void){
	switchEdge = true;
}

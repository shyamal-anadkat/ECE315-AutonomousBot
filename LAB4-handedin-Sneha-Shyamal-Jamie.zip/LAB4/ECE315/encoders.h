#ifndef __ENCODERS_H__
#define __ENCODERS_H__

//**function declarations***
float encode(float inches);

#endif
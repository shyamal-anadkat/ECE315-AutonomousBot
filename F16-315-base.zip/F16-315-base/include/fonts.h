#ifndef __FONTS_H__
#define __FONTS_H__

#include <stdint.h>

extern const uint8_t arialNarrow_8ptBitmaps[];
extern const uint8_t courierNew_10ptBitmaps[];
extern const uint8_t buckyBadger[];
extern const uint8_t motionW[];
#endif
